# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': 'src'}

packages = \
['deepec']

package_data = \
{'': ['*'], 'deepec': ['model/*']}

setup_kwargs = {
    'name': 'deepec',
    'version': '0.0.0',
    'description': 'Prediction of EC numbers for enzyme sequences',
    'long_description': '#DeepECtransformer\n##Procedure\n\n**Note**: \nThis source code was developed in Linux, and has been tested in Ubuntu 16.04 with Python 3.6.\n\n1. Clone the repository\n\n        git clone https://github.com/kaistsystemsbiology/DeepProZyme.git\n\n2. Create and activate virtual environment (takes 5~10 min)\n\n        conda env create -f environment.yml\n        conda activate deepectransformer\n\n3. To use gpus properly, install the pytorch and cuda for your gpus. This code was tested on pytorch=1.7.0 using cuda version 10.2\n\n\n\n##Example\n\n\n- Run DeepECtransformer (takes < 1 min)\n\n        python run_deepectransformer.py -i ./example/mdh_ecoli.fa -o ./example/results -g cpu -b 128 -cpu 2\n        python run_deepectransformer.py -i ./example/mdh_ecoli.fa -o ./example/results -g cuda:3 -b 128 -cpu 2\n',
    'author': 'Semidán Robaina Estévez',
    'author_email': 'semidan.robaina@gmail.com',
    'maintainer': 'Semidán Robaina Estévez',
    'maintainer_email': 'semidan.robaina@gmail.com',
    'url': '',
    'package_dir': package_dir,
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.6,<4.0',
}


setup(**setup_kwargs)
